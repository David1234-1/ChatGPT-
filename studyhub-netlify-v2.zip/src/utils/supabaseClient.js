import { SUPABASE_URL, SUPABASE_ANON_KEY } from '../../config.js';
export const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
  global: { headers: { 'x-studyhub': '2.0' } }
});
