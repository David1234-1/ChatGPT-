# StudyHub v2 (Esthétique + Realtime + Examen + GCal)

Améliorations majeures :
- 🎨 **UI moderne** (glassmorphism, gradients, animations légères)
- 📈 **Stats visibles** (scores, moyenne, cartes revues)
- 🧠 **Spaced Repetition** complet (SM‑2 via RPC `sm2_review`, vue Due)
- 👥 **Groupes + Chat Realtime** (channels Supabase)
- ⏱️ **Mode Examen** (timer global, sauvegarde score)
- 🔄 **Sync Google Calendar** (via token Google d’auth Supabase)

## Déploiement
- Importez `supabase/schema.sql` puis `supabase/policies.sql` (inclut RPCs, vues, tables groupes/messages).
- Netlify : variable `OPENAI_API_KEY` si vous voulez la génération IA côté function.
- Supabase Auth (Google) : ajoutez le scope `https://www.googleapis.com/auth/calendar` dans le provider Google.

## Notes
- La sync Google crée des évènements dans le calendrier primaire de l’utilisateur. Nécessite connexion via Google.
