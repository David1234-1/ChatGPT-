import { sb } from '../utils/supabaseClient.js';

export async function mountCalendar(root){
  root.innerHTML = `
    <div class="card strong">
      <div class="row" style="justify-content:space-between">
        <h2>📅 Calendrier</h2>
        <div class="row">
          <label>Catégorie <input class="input" id="catInput" placeholder="ex: Révision" /></label>
          <label>Couleur <input class="input" id="colorInput" type="color" value="#3b82f6" /></label>
          <button class="btn" id="syncGcal">🔄 Sync Google</button>
        </div>
      </div>
      <div id="calendar"></div>
    </div>
  `;

  const calendarEl = document.getElementById('calendar');
  const { data: events } = await sb.from('events').select('*').order('start_at');

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    height: 'auto',
    headerToolbar: { left:'prev,next today', center:'title', right:'dayGridMonth,timeGridWeek,timeGridDay,listWeek' },
    navLinks: true,
    selectable: true,
    selectMirror: true,
    select: async (info) => {
      const title = prompt('Titre de l\'événement:');
      if (title) {
        const cat = document.getElementById('catInput').value.trim() || null;
        const color = document.getElementById('colorInput').value || null;
        const { data, error } = await sb.from('events').insert({ title, start_at: info.startStr, end_at: info.endStr, category: cat, color, details: {} }).select().single();
        if (error) alert(error.message);
        else calendar.addEvent({ id: data.id, title, start: info.startStr, end: info.endStr, backgroundColor: color || undefined, borderColor: color || undefined });
      }
      calendar.unselect();
    },
    eventClick: async (info) => {
      const choice = prompt('Modifier le titre (laisser vide pour supprimer) :', info.event.title);
      if (choice === null) return;
      if (choice === '') { await sb.from('events').delete().eq('id', info.event.id); info.event.remove(); }
      else { await sb.from('events').update({ title: choice }).eq('id', info.event.id); info.event.setProp('title', choice); }
    },
    events: (events||[]).map(e => ({ id:e.id, title:e.title, start:e.start_at, end:e.end_at, backgroundColor:e.color||undefined, borderColor:e.color||undefined }))
  });
  calendar.render();

  document.getElementById('syncGcal').onclick = async ()=>{
    const { data:{ session } } = await sb.auth.getSession();
    const provider_token = session?.provider_token; // for Google OAuth sessions
    if (!provider_token){ alert('Connecte-toi avec Google pour synchroniser.'); return; }
    // Send all future events to Netlify function
    const now = new Date().toISOString();
    const { data: list } = await sb.from('events').select('*').gte('start_at', now).order('start_at');
    const res = await fetch('/.netlify/functions/sync_gcal', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ provider_token, events: list })
    });
    const out = await res.json();
    alert(res.ok ? `Synchronisé ${out.synced||0} évènements ✅` : (out.error||'Erreur sync'));
  };
}
