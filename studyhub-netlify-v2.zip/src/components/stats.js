import { sb } from '../utils/supabaseClient.js';

export async function mountStats(root){
  root.innerHTML = `
    <div class="card strong">
      <h2>📈 Statistiques</h2>
      <div class="grid cols-3">
        <div class="kpi"><div class="value" id="kAttempts">–</div><div class="label">Examens passés</div></div>
        <div class="kpi"><div class="value" id="kAvg">–</div><div class="label">Score moyen</div></div>
        <div class="kpi"><div class="value" id="kCards">–</div><div class="label">Cartes révisées</div></div>
      </div>
    </div>
    <div class="card">
      <h3>Historique des scores</h3>
      <canvas id="scoreChart" height="220"></canvas>
    </div>
  `;

  const [att, rev] = await Promise.all([
    sb.from('quiz_attempts').select('score,total,created_at').order('created_at'),
    sb.from('reviews').select('id'),
  ]);
  const attempts = att.data||[];
  const avg = attempts.length ? Math.round( (attempts.reduce((s,a)=>s+(a.score/a.total),0)/attempts.length) * 100 ) : 0;
  document.getElementById('kAttempts').textContent = attempts.length;
  document.getElementById('kAvg').textContent = isFinite(avg) ? (avg+'%') : '–';
  document.getElementById('kCards').textContent = rev.data?.length||0;

  // Minimal canvas chart (no external dep)
  const c = document.getElementById('scoreChart');
  const ctx = c.getContext('2d');
  const w = c.width = c.clientWidth; const h = c.height;
  ctx.clearRect(0,0,w,h);
  ctx.lineWidth = 2;
  ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent');
  ctx.beginPath();
  attempts.forEach((a,i)=>{
    const x = (i/(Math.max(1, attempts.length-1))) * (w-20) + 10;
    const y = h - ((a.score/a.total)*h*0.9) - 10;
    if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--brand');
    ctx.beginPath(); ctx.arc(x,y,3,0,Math.PI*2); ctx.fill();
  });
  ctx.stroke();
}
