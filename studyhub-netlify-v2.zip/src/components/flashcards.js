import { sb } from '../utils/supabaseClient.js';

function getCourseId(){ const m = location.hash.match(/course=([a-f0-9-]+)/i); return m ? m[1] : null; }

export async function mountFlashcards(root){
  const courseId = getCourseId();
  const { data: courses } = await sb.from('courses').select('id,title').order('created_at', { ascending:false });
  root.innerHTML = `
  <div class="card strong">
    <div class="row" style="justify-content:space-between">
      <h2>🎯 Flashcards (Spaced Repetition)</h2>
      <select id="courseSel" class="input">
        ${courses?.map(c=>`<option value="${c.id}" ${c.id===courseId?'selected':''}>${c.title}</option>`).join('')}
      </select>
    </div>
    <div id="deck"></div>
  </div>`;

  document.getElementById('courseSel').addEventListener('change', e=>{ location.hash = `#/flashcards?course=${e.target.value}`; });

  async function load(){
    const id = getCourseId() || courses?.[0]?.id;
    if (!id) return;
    // Next due cards based on reviews.next_review_at
    const { data: cards } = await sb.rpc('due_flashcards', { p_course_id: id });
    const deck = document.getElementById('deck');
    if (!cards?.length) { deck.innerHTML = '<div class="muted">Aucune carte due pour révision maintenant.</div>'; return; }
    let i = 0;
    function render(){
      const c = cards[i];
      deck.innerHTML = `
        <div class="card">
          <div class="badge">Carte ${i+1}/${cards.length}</div>
          <h3 id="face" style="cursor:pointer;user-select:none">${c.front}</h3>
          <div class="row">
            <button class="btn" id="again">Difficile</button>
            <button class="btn" id="good">Bien</button>
            <button class="btn" id="easy">Facile</button>
          </div>
        </div>`;
      const face = document.getElementById('face');
      face.onclick = ()=> { face.textContent = (face.textContent===c.front) ? c.back : c.front; };
      document.getElementById('again').onclick = ()=> grade(c.id, 1);
      document.getElementById('good').onclick = ()=> grade(c.id, 3);
      document.getElementById('easy').onclick = ()=> grade(c.id, 5);
    }
    async function grade(flashcard_id, grade){
      await sb.rpc('sm2_review', { p_flashcard_id: flashcard_id, p_grade: grade });
      i = (i+1)%cards.length; render();
    }
    render();
  }
  load();
}
