alter table public.events enable row level security;
alter table public.courses enable row level security;
alter table public.qcms enable row level security;
alter table public.flashcards enable row level security;
alter table public.summaries enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.reviews enable row level security;
alter table public.groups enable row level security;
alter table public.group_members enable row level security;
alter table public.messages enable row level security;

create policy "events_own" on public.events for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "courses_own" on public.courses for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "qcms_select_via_course" on public.qcms for select using (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid()));
create policy "qcms_crud_via_course" on public.qcms for all using (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid())) with check (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid()));

create policy "flashcards_select_via_course" on public.flashcards for select using (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid()));
create policy "flashcards_crud_via_course" on public.flashcards for all using (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid())) with check (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid()));

create policy "summaries_select_via_course" on public.summaries for select using (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid()));
create policy "summaries_crud_via_course" on public.summaries for all using (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid())) with check (exists (select 1 from public.courses c where c.id = course_id and c.user_id = auth.uid()));

create policy "quiz_attempts_own" on public.quiz_attempts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "reviews_own" on public.reviews for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Groups: owner can manage, members can read/write messages
create policy "groups_read_all" on public.groups for select using (true);
create policy "groups_owner_write" on public.groups for all using (owner = auth.uid()) with check (owner = auth.uid());

create policy "group_members_manage_own" on public.group_members for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "messages_read_member" on public.messages for select using (exists (select 1 from public.group_members gm where gm.group_id = group_id and gm.user_id = auth.uid()));
create policy "messages_write_member" on public.messages for insert with check (exists (select 1 from public.group_members gm where gm.group_id = group_id and gm.user_id = auth.uid()));
