import { sb } from '../utils/supabaseClient.js';

export async function mountGroups(root){
  root.innerHTML = `
    <div class="grid cols-2">
      <div class="card strong">
        <h2>👥 Groupes d'étude</h2>
        <div class="row">
          <input class="input" id="gname" placeholder="Nom du groupe"/>
          <button class="btn primary" id="create">Créer</button>
        </div>
        <ul id="myGroups"></ul>
      </div>
      <div class="card">
        <h2>💬 Chat (realtime)</h2>
        <div class="row">
          <select id="groupSel" class="input"></select>
        </div>
        <div class="chat" id="chat"></div>
        <div class="row" style="margin-top:8px">
          <input class="input" id="msg" placeholder="Votre message..." />
          <button class="btn primary" id="send">Envoyer</button>
        </div>
      </div>
    </div>
  `;

  const { data:{ user } } = await sb.auth.getUser();

  async function loadGroups(){
    const { data } = await sb.from('group_members').select('groups(id,name)').eq('user_id', user.id);
    const my = document.getElementById('myGroups'); my.innerHTML='';
    const sel = document.getElementById('groupSel'); sel.innerHTML='';
    (data||[]).forEach(gm=>{
      const g = gm.groups;
      const li = document.createElement('li'); li.textContent = `${g.name} (${g.id})`; my.append(li);
      const opt = document.createElement('option'); opt.value = g.id; opt.textContent = g.name; sel.append(opt);
    });
    if (sel.options.length) { sel.selectedIndex = 0; subscribe(sel.value); loadMessages(sel.value); }
  }

  document.getElementById('create').onclick = async ()=>{
    const name = document.getElementById('gname').value.trim(); if (!name) return;
    const { data: g, error } = await sb.from('groups').insert({ name }).select().single();
    if (error) { alert(error.message); return; }
    await sb.from('group_members').insert({ group_id: g.id, user_id: user.id });
    loadGroups();
  };

  async function loadMessages(group_id){
    const { data } = await sb.from('messages').select('id,content,created_at,user_id').eq('group_id', group_id).order('created_at',{ascending:true}).limit(200);
    const chat = document.getElementById('chat'); chat.innerHTML = '';
    (data||[]).forEach(m=> renderMsg(m));
  }

  let channel = null;
  function subscribe(group_id){
    if (channel) sb.removeChannel(channel);
    channel = sb.channel('room:'+group_id).on('postgres_changes', { event:'INSERT', schema:'public', table:'messages', filter:`group_id=eq.${group_id}` }, payload => {
      renderMsg(payload.new);
    }).subscribe();
  }

  function renderMsg(m){
    const chat = document.getElementById('chat');
    const div = document.createElement('div'); div.className = 'msg' + (m.user_id === sb.auth.user()?.id ? ' me' : '');
    const time = new Date(m.created_at).toLocaleTimeString();
    div.innerHTML = `<div class="muted" style="font-size:.8em">${time}</div>${m.content}`;
    chat.append(div);
    chat.scrollTop = chat.scrollHeight;
  }

  document.getElementById('groupSel').addEventListener('change', e=>{ subscribe(e.target.value); loadMessages(e.target.value); });

  document.getElementById('send').onclick = async ()=>{
    const sel = document.getElementById('groupSel'); if (!sel.value) return alert('Choisissez un groupe');
    const content = document.getElementById('msg').value.trim(); if (!content) return;
    await sb.from('messages').insert({ group_id: sel.value, content });
    document.getElementById('msg').value = '';
  };

  loadGroups();
}
