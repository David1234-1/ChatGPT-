import { sb } from './src/utils/supabaseClient.js';
import { mountDashboard } from './src/components/dashboard.js';
import { mountAuth } from './src/components/auth.js';
import { mountCalendar } from './src/components/calendar.js';
import { mountCourses } from './src/components/courses.js';
import { mountQCM } from './src/components/qcm.js';
import { mountFlashcards } from './src/components/flashcards.js';
import { mountSummaries } from './src/components/summaries.js';
import { mountStats } from './src/components/stats.js';
import { mountExam } from './src/components/exam.js';
import { mountGroups } from './src/components/groups.js';

const topnav = document.getElementById('topnav');
const userMenu = document.getElementById('userMenu');
const app = document.getElementById('app');

function navLink(title, hash) {
  const a = document.createElement('a');
  a.textContent = title;
  a.href = hash;
  if (location.hash === hash) a.classList.add('active');
  return a;
}

function renderNav(session) {
  topnav.innerHTML = '';
  if (!session) return;
  topnav.append(
    navLink('Dashboard', '#/dashboard'),
    navLink('Calendrier', '#/calendar'),
    navLink('Importation', '#/courses'),
    navLink('QCM', '#/qcm'),
    navLink('Flashcards', '#/flashcards'),
    navLink('Résumés', '#/summaries'),
    navLink('Stats', '#/stats'),
    navLink('Examen', '#/exam'),
    navLink('Groupes', '#/groups'),
  );

  userMenu.innerHTML = '';
  const span = document.createElement('span');
  span.className = 'badge';
  span.textContent = session.user.email;
  const btn = document.createElement('button');
  btn.className = 'btn';
  btn.textContent = 'Déconnexion';
  btn.onclick = async () => { await sb.auth.signOut(); location.hash = '#/auth'; };
  userMenu.append(span, btn);
}

document.getElementById('themeToggle').addEventListener('click', () => {
  const html = document.documentElement;
  html.setAttribute('data-theme', html.getAttribute('data-theme') === 'light' ? 'dark' : 'light');
  localStorage.setItem('theme', html.getAttribute('data-theme'));
});
const savedTheme = localStorage.getItem('theme');
if (savedTheme) document.documentElement.setAttribute('data-theme', savedTheme);

function route() {
  const hash = location.hash || '#/dashboard';
  app.innerHTML = '';
  if (hash.startsWith('#/auth')) return mountAuth(app);
  sb.auth.getSession().then(({ data: { session }}) => {
    renderNav(session);
    if (!session) return mountAuth(app);
    switch (hash) {
      case '#/dashboard': return mountDashboard(app);
      case '#/calendar': return mountCalendar(app);
      case '#/courses': return mountCourses(app);
      case '#/qcm': return mountQCM(app);
      case '#/flashcards': return mountFlashcards(app);
      case '#/summaries': return mountSummaries(app);
      case '#/stats': return mountStats(app);
      case '#/exam': return mountExam(app);
      case '#/groups': return mountGroups(app);
      default: return mountDashboard(app);
    }
  });
}
window.addEventListener('hashchange', route);
sb.auth.onAuthStateChange((_e, _s) => route());
route();
