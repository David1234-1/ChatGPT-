export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { content, course_id } = req.body || {};
    if (!content) return res.status(400).json({ error: 'Missing content' });

    const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
    let summary = ''; let qcms = []; let flashcards = [];

    if (OPENAI_API_KEY) {
      const prompt = [
        { role: 'system', content: 'Tu génères un résumé concis (<=200 mots), 20 QCM (4 options, answer=0..3) et 40 flashcards {front,back}. Réponds STRICTEMENT en JSON {"summary":"...", "qcms":[...], "flashcards":[...]}.' },
        { role: 'user', content: content.slice(0, 16000) }
      ];
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'gpt-4o-mini', messages: prompt, temperature: 0.2, response_format: { type: 'json_object' } })
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error?.message || 'OpenAI error');
      const parsed = JSON.parse(j.choices[0].message.content);
      summary = parsed.summary || '';
      qcms = (parsed.qcms||[]).slice(0, 40).map(q=>({ question: String(q.question||''), options: q.options?.slice(0,4) || [], answer: Number(q.answer||0) }));
      flashcards = (parsed.flashcards||[]).slice(0, 120).map(fc=>({ front: String(fc.front||''), back: String(fc.back||'') }));
    } else {
      summary = content.split('\n').slice(0, 20).join(' ').slice(0, 900);
      const sentences = content.split(/(?<=[.!?])\s+/).slice(0, 60);
      for (let i=0;i<Math.min(20, sentences.length);i++){
        const s = sentences[i]; const words = s.split(' ').filter(Boolean);
        if (words.length < 6) continue;
        const answerWord = words[Math.floor(words.length/2)].replace(/[^\wÀ-ÿ-]/g,'');
        const options = [answerWord, ...(words.slice(0,3)).map(w=>w.replace(/[^\wÀ-ÿ-]/g,'')).filter(Boolean)].slice(0,4);
        qcms.push({ question: 'Complétez: ' + s.replace(answerWord, '_____'), options, answer: 0 });
      }
      const lines = content.split('\n').filter(l=>l.trim()).slice(0, 80);
      flashcards = lines.slice(0, 40).map(l=>({ front: l.slice(0, 60), back: l.slice(60, 240) || l }));
    }

    return res.status(200).json({ course_id, summary, qcms, flashcards });
  } catch (e) {
    return res.status(500).json({ error: e.message || 'unknown error' });
  }
}
