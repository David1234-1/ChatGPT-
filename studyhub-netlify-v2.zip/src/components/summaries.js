import { sb } from '../utils/supabaseClient.js';
export async function mountSummaries(root){
  const { data } = await sb.from('summaries').select('id,course_id,content,created_at,courses(title)').order('created_at', { ascending:false });
  root.innerHTML = `
    <div class="card strong">
      <h2>📜 Résumés</h2>
      ${(data||[]).map(s=>`
        <details class="card" style="margin-top:10px">
          <summary><b>${s.courses?.title||'Cours'}</b> — <span class="muted">${new Date(s.created_at).toLocaleString()}</span></summary>
          <p style="white-space:pre-wrap">${s.content}</p>
        </details>
      `).join('')}
    </div>
  `;
}
