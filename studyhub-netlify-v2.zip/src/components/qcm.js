import { sb } from '../utils/supabaseClient.js';

function getCourseId(){ const m = location.hash.match(/course=([a-f0-9-]+)/i); return m ? m[1] : null; }

export async function mountQCM(root){
  const courseId = getCourseId();
  const { data: courses } = await sb.from('courses').select('id,title').order('created_at', { ascending:false });
  root.innerHTML = `
  <div class="card strong">
    <div class="row" style="justify-content:space-between">
      <h2>📝 QCM</h2>
      <select id="courseSel" class="input">
        ${courses?.map(c=>`<option value="${c.id}" ${c.id===courseId?'selected':''}>${c.title}</option>`).join('')}
      </select>
    </div>
    <div id="qcmList"></div>
    <hr/>
    <div class="row">
      <label>Nombre de questions <input class="input" id="nq" type="number" min="5" max="50" value="10"/></label>
      <button class="btn primary" id="startQuiz">Lancer un test</button>
    </div>
    <div id="quiz"></div>
  </div>`;

  document.getElementById('courseSel').addEventListener('change', e=>{ location.hash = `#/qcm?course=${e.target.value}`; });

  async function load(){
    const id = getCourseId() || courses?.[0]?.id;
    if (!id) return;
    const { data: qcms } = await sb.from('qcms').select('*').eq('course_id', id).limit(200);
    const list = document.getElementById('qcmList');
    list.innerHTML = `<div class="muted">${qcms?.length||0} questions.</div>`;
    document.getElementById('startQuiz').onclick = ()=> startQuiz(qcms||[], id);
  }
  load();
}

function shuffle(a){ for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]];} return a; }

async function startQuiz(qcms, courseId){
  const quiz = document.getElementById('quiz');
  const n = Math.max(5, Math.min(50, parseInt(document.getElementById('nq').value||'10', 10)));
  if (!qcms.length) { quiz.innerHTML = '<div class="muted">Aucune question disponible.</div>'; return; }
  const subset = shuffle(qcms.slice()).slice(0, n);
  let score = 0, idx = 0;
  const start = Date.now();

  const timerEl = document.createElement('div');
  timerEl.className = 'badge';
  let remaining = n * 45; // 45s/question
  const int = setInterval(()=>{ remaining--; timerEl.textContent = `⏱️ ${remaining}s`; if (remaining<=0){ clearInterval(int); finish(); } }, 1000);

  function render(){
    const q = subset[idx];
    quiz.innerHTML = ``;
    quiz.prepend(timerEl);
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `<h3>Question ${idx+1}/${subset.length}</h3><div class="card">${q.question}</div><div class="grid responsive" id="opts"></div>`;
    const opts = card.querySelector('#opts');
    q.options.forEach((opt, i)=>{
      const b = document.createElement('button'); b.className = 'btn'; b.textContent = opt;
      b.onclick = ()=>{ if (i===q.answer) { score++; b.classList.add('success'); } else { b.classList.add('danger'); }
        setTimeout(()=>{ idx++; (idx<subset.length)?render():finish(); }, 350);
      };
      opts.append(b);
    });
    quiz.append(card);
  }
  async function finish(){
    clearInterval(int);
    const elapsed = Math.round((Date.now()-start)/1000);
    quiz.innerHTML = `<h3>Terminé ✅</h3><div class="card">Score: <b>${score}</b> / ${subset.length} en ${elapsed}s</div>`;
    try {
      const { error } = await sb.from('quiz_attempts').insert({ course_id: courseId, score, total: subset.length, elapsed_seconds: elapsed });
      if (error) console.warn(error);
    } catch {}
  }
  render();
}
