// Push events to user's Google Calendar using provider_token from Supabase OAuth (Google)
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { provider_token, events } = req.body || {};
    if (!provider_token) return res.status(400).json({ error: 'Missing provider_token' });
    const synced = [];
    for (const e of (events||[])) {
      const payload = {
        summary: e.title,
        description: e.category || 'StudyHub',
        start: { dateTime: new Date(e.start_at).toISOString() },
        end: { dateTime: new Date(e.end_at || e.start_at).toISOString() },
      };
      const r = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${provider_token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (r.ok) synced.push(e.id);
    }
    res.status(200).json({ synced: synced.length });
  } catch (e) {
    res.status(500).json({ error: e.message || 'sync error' });
  }
}
