import { sb } from '../utils/supabaseClient.js';

export function mountCourses(root){
  const html = `
    <div class="grid responsive">
      <div class="card strong">
        <h2>📂 Importation de cours</h2>
        <div id="drop" style="border:2px dashed var(--border); border-radius:12px; padding:20px; text-align:center">
          Glissez-déposez vos fichiers ici (PDF/TXT)<br>
          <span class="muted">ou</span><br>
          <input id="file" type="file" accept=".pdf,.txt" multiple />
        </div>
        <div id="list" style="margin-top:12px"></div>
      </div>
      <div class="card">
        <h3>Vos cours</h3>
        <table class="table" id="coursesTable">
          <thead><tr><th>Titre</th><th>Fichier</th><th>Créé</th></tr></thead>
          <tbody></tbody>
        </table>
      </div>
    </div>
  `;
  root.innerHTML = html;

  const drop = document.getElementById('drop');
  const file = document.getElementById('file');
  const list = document.getElementById('list');

  const prevent = e => { e.preventDefault(); e.stopPropagation(); };
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, prevent));
  drop.addEventListener('drop', (e)=> handleFiles(e.dataTransfer.files));
  file.addEventListener('change', (e)=> handleFiles(e.target.files));

  async function handleFiles(files) {
    for (const f of files) {
      const row = document.createElement('div');
      row.className = 'card';
      row.innerHTML = `<b>${f.name}</b> <span class="badge">${Math.round(f.size/1024)} ko</span>
      <div class="progress"><div></div></div>
      <div class="muted" style="margin-top:6px">Extraction & analyse…</div>`;
      const bar = row.querySelector('.progress div');
      list.prepend(row);

      // Read content
      let content = '';
      if (f.type === 'text/plain' || f.name.toLowerCase().endswith('.txt')) {
        content = await f.text();
      } else if (f.type === 'application/pdf' || f.name.toLowerCase().endswith('.pdf')) {
        content = await extractPdf(await f.arrayBuffer(), p => bar.style.width = p + '%');
      } else { row.querySelector('.muted').textContent = 'Format non supporté'; continue; }
      bar.style.width = '60%';
      // Save file to storage
      const { data: user } = await sb.auth.getUser();
      const path = `${user.user.id}/${Date.now()}_${f.name}`;
      await sb.storage.from('courses').upload(path, f, { upsert: true });
      // Insert course
      const title = f.name.replace(/\.(pdf|txt)$/i, '');
      const { data: course, error } = await sb.from('courses').insert({ title, file_name: f.name, content }).select().single();
      if (error) { alert(error.message); continue; }
      bar.style.width = '80%';
      // Call AI function
      try {
        const res = await fetch('/.netlify/functions/generate', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ course_id: course.id, content }) });
        const out = await res.json();
        if (!res.ok) throw new Error(out.error || 'Erreur IA');
        if (out.qcms?.length) await sb.from('qcms').insert(out.qcms.map(q=>({...q, course_id: course.id })));
        if (out.flashcards?.length) await sb.from('flashcards').insert(out.flashcards.map(fc=>({...fc, course_id: course.id })));
        if (out.summary) await sb.from('summaries').insert({ course_id: course.id, content: out.summary });
        bar.style.width = '100%'; row.querySelector('.muted').textContent = 'Terminé ✅';
      } catch (e) {
        console.warn(e); row.querySelector('.muted').textContent = 'Analyse IA indisponible, cours créé sans QCM/flashcards.'; bar.style.width = '100%';
      }
      loadCourses();
    }
  }
  async function extractPdf(buffer, onProgress) {
    const pdf = await window['pdfjs-dist/build/pdf'].getDocument({ data: buffer }).promise;
    let text = '';
    for (let i=1;i<=pdf.numPages;i++){
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      text += content.items.map(it=>it.str).join(' ') + "\n\n";
      onProgress(Math.round( (i/pdf.numPages)*60 ));
    }
    return text;
  }
  async function loadCourses(){
    const { data } = await sb.from('courses').select('id,title,file_name,created_at').order('created_at', { ascending: false });
    const tbody = document.querySelector('#coursesTable tbody');
    tbody.innerHTML='';
    (data||[]).forEach(c=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `<td><a href="#/qcm?course=${c.id}">${c.title}</a></td><td>${c.file_name}</td><td>${new Date(c.created_at).toLocaleString()}</td>`;
      tbody.append(tr);
    })
  }
  loadCourses();
}
