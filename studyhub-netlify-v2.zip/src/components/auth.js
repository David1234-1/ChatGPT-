import { sb } from '../utils/supabaseClient.js';

export function mountAuth(root){
  root.innerHTML = `
  <div class="grid responsive">
    <div class="card strong">
      <h2>Connexion</h2>
      <form id="loginForm">
        <label>Email<input class="input" name="email" type="email" required /></label>
        <label>Mot de passe<input class="input" name="password" type="password" required minlength="6" /></label>
        <div class="row">
          <button class="btn primary" type="submit">Se connecter</button>
          <button class="btn" id="loginGoogle" type="button">Continuer avec Google</button>
        </div>
      </form>
      <p><a href="#" id="forgot">Mot de passe oublié ?</a></p>
    </div>
    <div class="card">
      <h2>Créer un compte</h2>
      <form id="signupForm">
        <label>Email<input class="input" name="email" type="email" required /></label>
        <label>Mot de passe<input class="input" name="password" type="password" required minlength="6" /></label>
        <button class="btn primary" type="submit">Créer le compte</button>
      </form>
    </div>
  </div>
  `;

  document.getElementById('loginForm').addEventListener('submit', async (e)=>{
    e.preventDefault();
    const email = e.target.email.value.trim();
    const password = e.target.password.value;
    const { error } = await sb.auth.signInWithPassword({ email, password });
    if (error) alert(error.message); else location.hash = '#/dashboard';
  });
  document.getElementById('loginGoogle').addEventListener('click', async ()=>{
    const { error } = await sb.auth.signInWithOAuth({ provider:'google', options:{ scopes: 'https://www.googleapis.com/auth/calendar' } });
    if (error) alert(error.message);
  });
  document.getElementById('forgot')?.addEventListener('click', async ()=>{
    const email = prompt('Votre email ?'); if (!email) return;
    const redirectTo = `${location.origin}/#/auth`;
    const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo });
    alert(error ? error.message : 'Email envoyé !');
  });
  document.getElementById('signupForm').addEventListener('submit', async (e)=>{
    e.preventDefault();
    const email = e.target.email.value.trim();
    const password = e.target.password.value;
    const { error } = await sb.auth.signUp({ email, password });
    if (error) alert(error.message); else alert('Compte créé ! Vérifiez votre email.');
  });
}
