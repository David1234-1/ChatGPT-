import { sb } from '../utils/supabaseClient.js';

export async function mountDashboard(root){
  root.innerHTML = `
    <div class="grid responsive">
      <div class="card strong">
        <h1 style="margin:0">Bienvenue 👋</h1>
        <p class="muted" style="margin-top:4px">Tout pour réussir ta PASS : importer, réviser, mesurer ta progression.</p>
        <div class="row" style="gap:10px; flex-wrap:wrap; margin-top:8px">
          <a class="btn primary" href="#/calendar">📅 Calendrier</a>
          <a class="btn" href="#/courses">📂 Importer</a>
          <a class="btn" href="#/qcm">📝 QCM</a>
          <a class="btn" href="#/flashcards">🎯 Flashcards</a>
          <a class="btn" href="#/exam">⏱️ Examen</a>
          <a class="btn" href="#/stats">📈 Stats</a>
          <a class="btn" href="#/groups">👥 Groupes</a>
        </div>
      </div>
      <div class="card">
        <h3>Indicateurs</h3>
        <div class="grid cols-3">
          <div class="kpi"><div class="value" id="k1">–</div><div class="label">Cours</div></div>
          <div class="kpi"><div class="value" id="k2">–</div><div class="label">QCM</div></div>
          <div class="kpi"><div class="value" id="k3">–</div><div class="label">Flashcards</div></div>
        </div>
      </div>
    </div>
  `;

  const [c,q,f] = await Promise.all([
    sb.from('courses').select('id', { count:'exact', head:true }),
    sb.from('qcms').select('id', { count:'exact', head:true }),
    sb.from('flashcards').select('id', { count:'exact', head:true }),
  ]);
  document.getElementById('k1').textContent = c.count||0;
  document.getElementById('k2').textContent = q.count||0;
  document.getElementById('k3').textContent = f.count||0;
}
