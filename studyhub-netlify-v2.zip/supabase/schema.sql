create extension if not exists "uuid-ossp";

-- Events
create table if not exists public.events (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade default auth.uid(),
  title text not null,
  start_at timestamp not null,
  end_at timestamp,
  category text,
  color text,
  details jsonb,
  created_at timestamp default now()
);

-- Courses
create table if not exists public.courses (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade default auth.uid(),
  title text,
  file_name text,
  content text,
  created_at timestamp default now()
);

-- QCM
create table if not exists public.qcms (
  id uuid primary key default uuid_generate_v4(),
  course_id uuid references public.courses(id) on delete cascade,
  question text,
  options text[],
  answer integer,
  created_at timestamp default now()
);

-- Flashcards
create table if not exists public.flashcards (
  id uuid primary key default uuid_generate_v4(),
  course_id uuid references public.courses(id) on delete cascade,
  front text,
  back text,
  created_at timestamp default now()
);

-- Summaries
create table if not exists public.summaries (
  id uuid primary key default uuid_generate_v4(),
  course_id uuid references public.courses(id) on delete cascade,
  content text,
  created_at timestamp default now()
);

-- Quiz attempts (stats + exam mode)
create table if not exists public.quiz_attempts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade default auth.uid(),
  course_id uuid references public.courses(id) on delete cascade,
  score integer,
  total integer,
  elapsed_seconds integer,
  created_at timestamp default now()
);

-- Spaced repetition reviews (SM-2 minimal data)
create table if not exists public.reviews (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade default auth.uid(),
  flashcard_id uuid references public.flashcards(id) on delete cascade,
  ease real default 2.5,           -- SM-2 'EF'
  interval_days integer default 0, -- I
  reps integer default 0,          -- n
  next_review_at timestamp default now(),
  last_grade smallint
);

-- Study groups
create table if not exists public.groups (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  owner uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamp default now()
);
create table if not exists public.group_members (
  group_id uuid references public.groups(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  created_at timestamp default now(),
  primary key (group_id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default uuid_generate_v4(),
  group_id uuid references public.groups(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade default auth.uid(),
  content text not null,
  created_at timestamp default now()
);

-- Helper view / function: due flashcards for a course
create or replace function public.due_flashcards(p_course_id uuid)
returns table(id uuid, front text, back text)
language sql stable as $$
  select f.id, f.front, f.back
  from public.flashcards f
  left join public.reviews r on r.flashcard_id = f.id and r.user_id = auth.uid()
  where f.course_id = p_course_id
    and coalesce(r.next_review_at, now() - interval '1 day') <= now()
  order by coalesce(r.next_review_at, now() - interval '1 day') asc
  limit 100;
$$;

-- SM-2 review step as RPC (grade ∈ {1,2,3,4,5})
create or replace function public.sm2_review(p_flashcard_id uuid, p_grade smallint)
returns void
language plpgsql security definer as $$
declare
  v reviews%rowtype;
  new_ease real;
  new_interval integer;
  new_reps integer;
begin
  select * into v from reviews where user_id = auth.uid() and flashcard_id = p_flashcard_id;
  if not found then
    insert into reviews(user_id, flashcard_id, ease, interval_days, reps, next_review_at, last_grade)
    values (auth.uid(), p_flashcard_id, 2.5, 0, 0, now(), null)
    returning * into v;
  end if;

  -- SM-2 adjustments
  if p_grade < 3 then
    new_reps := 0;
    new_interval := 1;
  else
    new_reps := v.reps + 1;
    if new_reps = 1 then new_interval := 1;
    elsif new_reps = 2 then new_interval := 6;
    else new_interval := round(v.interval_days * v.ease)::int;
    end if;
  end if;

  new_ease := greatest(1.3, v.ease + (0.1 - (5 - p_grade) * (0.08 + (5 - p_grade) * 0.02)));

  update reviews
    set ease = new_ease,
        interval_days = new_interval,
        reps = new_reps,
        next_review_at = now() + make_interval(days => new_interval),
        last_grade = p_grade
  where id = v.id;
end;
$$;
