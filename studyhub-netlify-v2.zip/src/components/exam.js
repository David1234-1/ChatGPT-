import { sb } from '../utils/supabaseClient.js';

function getCourseId(){ const m = location.hash.match(/course=([a-f0-9-]+)/i); return m ? m[1] : null; }

export async function mountExam(root){
  const { data: courses } = await sb.from('courses').select('id,title').order('created_at',{ascending:false});
  root.innerHTML = `
    <div class="card strong">
      <h2>⏱️ Mode Examen</h2>
      <div class="row">
        <select id="courseSel" class="input">
          ${courses?.map(c=>`<option value="${c.id}" ${c.id===getCourseId()?'selected':''}>${c.title}</option>`).join('')}
        </select>
        <label>Questions <input class="input" id="nq" type="number" min="10" max="100" value="30"/></label>
        <label>Temps (min) <input class="input" id="mins" type="number" min="5" max="180" value="45"/></label>
        <button class="btn primary" id="go">Démarrer</button>
      </div>
      <div id="exam"></div>
    </div>
  `;

  document.getElementById('go').onclick = async ()=>{
    const courseId = document.getElementById('courseSel').value;
    const nq = parseInt(document.getElementById('nq').value,10);
    const mins = parseInt(document.getElementById('mins').value,10);
    const { data: qcms } = await sb.from('qcms').select('*').eq('course_id', courseId);
    if (!qcms?.length) { alert('Pas assez de questions'); return; }
    startExam(qcms, nq, mins, courseId);
  };
}

function shuffle(a){ for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]];} return a; }

async function startExam(qcms, nq, mins, courseId){
  const examEl = document.getElementById('exam');
  const subset = shuffle(qcms.slice()).slice(0, nq);
  let score=0, idx=0;
  let remaining = mins*60;
  const timer = document.createElement('div'); timer.className='badge'; examEl.innerHTML=''; examEl.prepend(timer);
  const int = setInterval(()=>{ remaining--; timer.textContent = `⏱️ ${Math.floor(remaining/60)}:${String(remaining%60).padStart(2,'0')}`; if (remaining<=0){ clearInterval(int); finish(); } }, 1000);

  function render(){
    const q = subset[idx];
    const box = document.createElement('div'); box.className = 'card'; box.innerHTML = `<h3>${idx+1}/${subset.length}</h3><div class="card">${q.question}</div><div id="opts" class="grid responsive"></div>`;
    const opts = box.querySelector('#opts');
    q.options.forEach((opt,i)=>{
      const b = document.createElement('button'); b.className='btn'; b.textContent=opt;
      b.onclick = ()=>{ if (i===q.answer) { score++; b.classList.add('success'); } else { b.classList.add('danger'); } setTimeout(()=>{ idx++; (idx<subset.length)?next():finish(); }, 250); };
      opts.append(b);
    });
    examEl.append(box);
  }
  function next(){ examEl.innerHTML=''; examEl.prepend(timer); render(); }
  async function finish(){
    clearInterval(int);
    examEl.innerHTML = `<div class="card"><h3>Résultat</h3><p>Score ${score}/${subset.length}</p></div>`;
    try { await sb.from('quiz_attempts').insert({ course_id: courseId, score, total: subset.length, elapsed_seconds: mins*60 - remaining }); } catch{}
  }
  render();
}
